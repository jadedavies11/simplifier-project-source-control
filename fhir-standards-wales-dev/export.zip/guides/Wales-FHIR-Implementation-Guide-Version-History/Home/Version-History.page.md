## Wales FHIR Implementation Guide Version History

Implementation Guide version history is provided in the table below. 


<table class="table table-striped">
	<thead>
		<tr>
			<th scope="col">Date</th>
			<th scope="col">IG Version</th>
			<th scope="col">FHIR Version</th>
			<th scope="col">UK Core Version</th>
			<th scope="col">Description</th>
			<th scope="col">Guide</th>
			<th scope="col">Release Notes</th>
			<th scope="col">Package</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td scope="row">04/09/2026</td>
			<td>2.7.0-ballot.1 STU2</td>
			<td>4.0.1</td>
			<td>2.0.2</td>
			<td>In addition to general maintenance, this release includes changes which in the main will support: the Choose Pharmacy service, error workflows for care documents and complexities around organisation and location data (e.g. type classification, regions and clusters)</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-test?version=2.7.0-ballot.1">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-test/Home/Help-and-Support/Release-Notes?version=2.7.0-ballot.1">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.test/2.7.0-ballot.1">fhir.r4.wales.test 2.7.0-ballot.1</a>
			</td>
		</tr>
		<tr>
			<td scope="row">10/07/2026</td>
			<td>2.6.1 STU2</td>
			<td>4.0.1</td>
			<td>2.0.1</td>
			<td>Urgent Correction Release. This release contains urgent corrections to DocumentReference and related resources, discovered during early use by the NHS Wales Care Documents Service of the newly activated DataStandardsWales-DocumentReference profile in the Wales FHIR Implementation Guide v2.6.0. It also contains a correction of a misleading Practitioner identifier slice name for registered pharmacists.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.6.1">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.6.1">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales/2.6.1">fhir.r4.wales 2.6.1</a>
			</td>
		</tr>
		 <tr>
            <td scope="row">29/05/2026</td>
            <td>2.6.0 STU2</td>
            <td>4.0.1</td>
            <td>2.0.1</td>
            <td>Minor release that contains resources to support Document Reference. This was following a lengthy period of review to allow us to make the profile active. New example bundles have also been provided. Additionally, organization type slices have been added to further support the identification of different entities. Many additional quality of life changes made to the guide. Also added in support for R5 backports with a new package dependency that contains these resources.</td>
            <td>
                <a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.6.0">Home Page</a>
            </td>
            <td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.6.0">Release Notes</a></td>
            <td>
                <a href="https://simplifier.net/packages/fhir.r4.wales/2.6.0">fhir.r4.wales 2.6.0</a>
            </td>
        </tr>
		<tr>
			<td scope="row">26/03/2026</td>
			<td>2.5.0 STU2</td>
			<td>4.0.1</td>
			<td>2.0.1</td>
			<td>Minor release to move several resources to v1.0.0. Changes to the draft DocumentReference made available for review to move it to v1.0.0 in next release. MessageDefinition and MessageHeader profiles have also been added to support UEC.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.5.0">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.5.0">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales/2.5.0">fhir.r4.wales 2.5.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">20/11/2025</td>
			<td>2.4.0 STU2</td>
			<td>4.0.1</td>
			<td>2.0.1</td>
			<td>This is a minor release to support WPAS work being undertaken in the CDR and general quality improvements.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.4.0">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.4.0">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales/2.4.0">fhir.r4.wales 2.4.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">29/09/2025</td>
			<td>2.3.0 STU2</td>
			<td>4.0.1</td>
			<td>2.0.1</td>
			<td>This is a minor release to support the implementation of Immunizations, Diagnostics and Document Reference.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.3.0">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.3.0">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales/2.3.0">fhir.r4.wales 2.3.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">07/04/2025</td>
			<td>2.2.0 STU2</td>
			<td>4.0.1</td>
			<td>2.0.1</td>
			<td>This is a minor release to support the Growth Chart project.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.2.0">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.2.0">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales/2.2.0">fhir.r4.wales 2.2.0</a>
			</td>
		</tr>
		<tr>
<td scope="row">29/01/2025</td>
			<td>2.1.0 STU2</td>
			<td>4.0.1</td>
			<td>2.0.1</td>
			<td>This is a minor release to support the Growth Chart project.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.1.0">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.1.0">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales/2.1.0">fhir.r4.wales 2.1.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">02/12/2024</td>
			<td>2.0.0 STU2</td>
			<td>4.0.1</td>
			<td>2.0.1</td>
			<td>This is a major release to align the Data Standards Wales resources with the STU2 release of UK Core</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=2.0.0">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=2.0.0">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales/2.0.0">fhir.r4.wales 2.0.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">14/10/2024</td>
			<td>1.2.1 - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>This is a minor release to support the demographics work being undertaken in the CDR.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=1.2.1">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=1.2.1">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.STU1/1.2.1">fhir.r4.wales 1.2.1</a>
			</td>
		</tr>
		<tr>
			<td scope="row">10/07/2024</td>
			<td>1.1.1 - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>This is a minor release to support the demographics work being undertaken in the CDR.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=1.1.1">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-Implementation-Guide/Home/Help-and-Support/Release-Notes?version=1.1.1">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.STU1/1.1.1">fhir.r4.wales 1.1.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">24/05/2024</td>
			<td>1.1.0 - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>This is a minor release to support the demographics work being undertaken in the CDR and general quality improvements.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=1.1.0">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-Implementation-Guide/Home/Help-and-Support/Release-Notes?version=1.1.0">Release Notes</a></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.STU1/1.1.0">fhir.r4.wales 1.1.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">05/12/2023</td>
			<td>1.0.1 - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>Errata following release feedback.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=1.0.1">Home Page</a>
			</td>
			<td><a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide/Home/Help-and-Support/Release-Notes?version=1.0.1">Release Notes</a></td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.STU1/1.0.1">fhir.r4.wales 1.0.1</a>
			</td>
		</tr>
		<tr>
			<td scope="row">18/08/2023</td>
			<td>1.0.0 - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>Changes made following feedback from the publication of the pre-release.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=1.0.0">Home Page</a>
			</td>
			<td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.STU1/1.0.0">fhir.r4.wales 1.0.0</a>
			</td>
		</tr>
		<tr>
			<td scope="row">04/08/2023</td>
			<td>1.0.0-prerelease - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>Changes made based on the feedback recieved from the ballot process</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=1.0.0-prerelease">Home Page</a>
			</td>
			<td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.STU1/1.0.0-prerelease">fhir.r4.wales 1.0.0-prerelease</a>
			</td>
		</tr>
		<tr>
			<td scope="row">31/05/2023</td>
			<td>0.1.1 - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>Minor errata to fix asset rendering issues.</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=0.1.1-ballot">Home Page</a>
			</td>
			<td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.STU1/0.1.1-ballot">fhir.r4.wales 0.1.1-ballot</a>
			</td>
		</tr>
		<tr>
			<td scope="row">26/05/2023</td>
			<td>0.1.0 - STU1</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>First release of NHS Wales for Ballot containing updates following extensive development since February 2023.</td>
			<td>Withdrawn</td>
			<td></td>
			<td>Unlisted</td>
		</tr>
		<tr>
			<td scope="row">21/04/2023</td>
			<td>0.0.5 - Discovery</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>Discovery version - published Immunization and MedicationAdministration profiles for early comment and feedback</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=0.0.5-discovery">Home Page</a>
			</td>
			<td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.discovery/0.0.5">fhir.r4.wales 0.0.5-discovery</a>
			</td>
		</tr>
		<tr>
			<td scope="row">31/03/2023</td>
			<td>0.0.4 - Discovery</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>Discovery version - published MedicationDispense and MedicationRequest profiles for early comment and feedback</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=0.0.4-discovery">Home Page</a>
			</td>
			<td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.discovery/0.0.4">fhir.r4.wales 0.0.4-discovery</a>
			</td>
		</tr>
		<tr>
			<td scope="row">01/01/2023</td>
			<td>0.0.3 - Discovery</td>
			<td>4.0.1</td>
			<td>1.0.0</td>
			<td>Discovery version - published Diagnostics guidance and Profiles for early comment and feedback</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=0.0.3-discovery">Home Page</a>
			</td>
			<td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.discovery/0.0.3">fhir.r4.wales 0.0.3-discovery</a>
			</td>
		</tr>
		<tr>
			<td scope="row">13/10/2022</td>
			<td>0.0.2 - Discovery</td>
			<td>4.0.1</td>
			<td>0.1.0</td>
			<td>Discovery version - published Diagnostics guidance and Profiles for early comment and feedback</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=0.0.2-discovery">Home Page</a>
			</td>
			<td></td>
			<td>Not Released</td>
		</tr>
		<tr>
			<td scope="row">28/06/2022</td>
			<td>0.0.1 - Discovery</td>
			<td>4.0.1</td>
			<td>0.1.0</td>
			<td>Discovery version - published for early comment and feedback</td>
			<td>
				<a href="https://simplifier.net/guide/fhir-standards-wales-implementation-guide?version=0.0.1-discovery">Home Page</a>
			</td>
			<td></td>
			<td>
				<a href="https://simplifier.net/packages/fhir.r4.wales.discovery/0.0.1">fhir.r4.wales 0.0.1-discovery</a>
			</td>
		</tr>
	</tbody>
</table>

