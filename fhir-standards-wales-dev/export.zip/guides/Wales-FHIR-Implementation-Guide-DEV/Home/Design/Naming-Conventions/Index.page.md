<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

These naming conventions are applicable to FHIR conformance (i.e. StructureDefinition, CodeSystem, ConceptMap, ValueSet, etc.) resources published within Data Standards Wales FHIR profiles and as part of this implementation guide.