### {{page-title}}
The diagram below shows the typical relationship between NHS Wales primary and secondary care organizations and locations.

{{render:images-organization-and-location.drawio}}

