## Profiles

This implementation guide include the following active resources for medicines:

* {{pagelink:DataStandardsWales-Medication}}
* {{pagelink:DataStandardsWales-MedicationAdministration}}
* {{pagelink:DataStandardsWales-MedicationDispense}}
* {{pagelink:DataStandardsWales-MedicationList}}
* {{pagelink:DataStandardsWales-MedicationRequest}}
* {{pagelink:DataStandardsWales-MedicationStatement}}

The following profiles are currently in draft/experimental:

* {{pagelink:DataStandardsWales-Dosage}}
* {{pagelink:DataStandardsWales-Immunization}}

## Clinical Scenarios

Below is a list of all of the available scenarios pertaining to medications: