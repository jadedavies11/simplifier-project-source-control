### {{page-title}}
The diagram below show how clinicians and their roles are modelled in FHIR.

{{render:images-practitioner-and-practitionerrole.drawio}}