### {{page-title}}

The following Extensions have been defined for this implementation guide.

* {{pagelink:Extension-DataStandardsWales-CDRPatientRecordType}}
* {{pagelink:Extension-DataStandardsWales-CDRSourceTimeStamp}}
* {{pagelink:Extension-DataStandardsWales-DemographicsAsRecorded}}
* {{pagelink:Extension-DataStandardsWales-MedicationCourseOfTherapyType}}
* {{pagelink:Extension-DataStandardsWales-Occupation}}
* {{pagelink:Extension-DataStandardsWales-Religion}}

