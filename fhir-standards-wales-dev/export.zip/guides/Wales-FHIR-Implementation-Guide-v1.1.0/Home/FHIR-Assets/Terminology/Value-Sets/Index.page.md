### {{page-title}}

The following Value Sets have been defined for this implementation guide:

* {{pagelink:ValueSet-DataStandardsWales-GenderIdentity, text:ValueSet-DataStandardsWales-GenderIdentity}}
* {{pagelink:ValueSet-DataStandardsWales-MaritalStatus, text:ValueSet-DataStandardsWales-MaritalStatus}}
* {{pagelink:ValueSet-DataStandardsWales-ProvenanceActivity, text:ValueSet-DataStandardsWales-ProvenanceActivity}}
* {{pagelink:ValueSet-DataStandardsWales-Occupation, text:ValueSet-DataStandardsWales-Occupation}}
* {{pagelink:ValueSet-DataStandardsWales-Religion, text:ValueSet-DataStandardsWales-Religion}}
* {{pagelink:ValueSet-DataStandardsWales-Sex, text:ValueSet-DataStandardsWales-Sex}}
* {{pagelink:ValueSet-DataStandardsWales-Title, text:ValueSet-DataStandardsWales-Title}}
* {{pagelink:ValueSet-DataStandardsWales-WrrsTaskType, text:ValueSet-DataStandardsWales-WrrsTaskType}}
