<div class="warning"><span class="ImplementWarn"></span></div>

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-PatientRecordType, text:DataStandardsWales-Occupation}}