### {{page-title}}

The following MessageDefinition instances have been defined for this implementation guide.

* {{pagelink:MessageDefinition-DataStandardsWales-UEC-Arrival}}