<tabs>
  <tab title="Tree view">
    {{tree, buttons}}
  </tab>
  <tab title="Detailed view">
    {{dict}}
  </tab>
   <tab title="Table view">
    {{table}}
  </tab>
  <tab title="XML">
    {{xml}}
  </tab>
  <tab title="JSON">
    {{json}}
  </tab>

</tabs>