## Example Bundle - Degraded Allergies

This example references the following example resources:
* Allergies:
  * {{pagelink:Example-DataStandardsWales-AllergyIntolerance-DegradedMorphine, text:Degraded morphine allergy}}
  * {{pagelink:Example-DataStandardsWales-AllergyIntolerance-Potato, text:Potato allergy}}
  * {{pagelink:Example-DataStandardsWales-AllergyIntolerance-DegradedAspirin, text:Degraded aspirin allergy}}
  * {{pagelink:Example-DataStandardsWales-AllergyIntolerance-DegradedWasps, text:Degraded wasp allergy}}
* Subject, source and context:
  * {{pagelink:Example-DataStandardsWales-Patient-AliceJones, text:Patient - Alice Jones}}
  * {{pagelink:Example-DataStandardsWales-Practitioner-Consultant, text:Practitioner - Dr Dhiren Patel }}


<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:fhir-standards-wales/example-datastandardswales-bundle-allergies-degraded}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:fhir-standards-wales/example-datastandardswales-bundle-allergies-degraded}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:fhir-standards-wales/example-datastandardswales-bundle-allergies-degraded}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:fhir-standards-wales/example-datastandardswales-bundle-allergies-degraded}}
    </div>       
  </div>
</div>