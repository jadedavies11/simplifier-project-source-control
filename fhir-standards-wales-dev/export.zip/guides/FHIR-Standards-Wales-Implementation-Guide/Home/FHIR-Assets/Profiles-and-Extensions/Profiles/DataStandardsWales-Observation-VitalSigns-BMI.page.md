## {{page-title}}

### Overview
The [Observation VitalSigns BMI](https://www.hl7.org/fhir/r4/observation.html) resource contains additional support when measuring and recording body mass index about an individual receiving health or care-related services.

The {{page-title}} profile is derived from the {{pagelink:DataStandardsWales-Observation-VitalSigns, text: Data Standards Wales Observation - Vital Signs Profile}}. It defines additional rules for use when the observation is a BMI measurement. It has drawn on UK Core - Observation - BMI v 1.0.0 which is not yet included in a balloted release, for guidance on specific content and constraints for use when the observation is a BMI measurement.

A direct link to the Data Standards Wales asset can be accessed here - {{link:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Observation-VitalSigns-BMI}}


### Formal Views of Profile Content
<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink tab-active" onclick="openCity(this,'tabsnap')" data-target="tabsnap">
      Snapshot View
    </li>
    <li class="tablink" onclick="openCity(this,'tabdiff')" data-target="tabdiff">
      Differential View
    </li>
    <li class="tablink" onclick="openCity(this,'tabhybrid')" data-target="tabhybrid">
      Hybrid View
    </li>
    <li class="tablink" onclick="openCity(this,'tabeg')" data-target="tabeg">
      Examples
    </li>     
  </ul>
  <div class="tab-main">
    <div id="tabsnap" class="tabcontent active">      
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Observation-VitalSigns-BMI, snapshot}}
    </div>
    <div id="tabdiff" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Observation-VitalSigns-BMI, diff}}
  </div>
    <div id="tabhybrid" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Observation-VitalSigns-BMI, hybrid}}
  </div>
  <div id="tabeg" class="tabcontent">
  </div> 
    <list>
      <li>{{pagelink:Example-Observation-VitalSigns-BMI, text: Example Observation Vital Signs - BMI}}</li>
    </list>  
</div>

### Mandatory and Must Support Data Elements
Refer to the {{pagelink:Mandatory-and-Must-Support-Data-Elements,text: Mandatory and Must Support}} page for guidance on how these elements should be interpreted.