## Example Cluster Affiliation - Amman Gwendraeth and Amman Tawe Partnership

This example Organization Affiliation resource represents the participation of the Amman Tawe Partnership main surgery and two branch surgeries in the Amman Gwendraeth primary care cluster.

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:OrganizationAffiliation/Example-OrganizationAffiliation-CC201-W00142}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:OrganizationAffiliation/Example-OrganizationAffiliation-CC201-W00142}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:OrganizationAffiliation/Example-OrganizationAffiliation-CC201-W00142}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:OrganizationAffiliation/Example-OrganizationAffiliation-CC201-W00142}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:OrganizationAffiliation/Example-OrganizationAffiliation-CC201-W00142}}
    </div>  
  </div>
</div>