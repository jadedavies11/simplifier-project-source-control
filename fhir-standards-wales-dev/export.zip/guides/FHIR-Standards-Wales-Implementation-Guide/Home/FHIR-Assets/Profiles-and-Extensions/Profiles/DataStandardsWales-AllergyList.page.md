## {{page-title}}

### Overview
The [List](https://www.hl7.org/fhir/r4/list.html) resource is a curated collection of resources. The Allergy List profile is intended to provide a snapshot view of a patient's allergies.

The {{page-title}} profile is derived from the [UK Core List Profile](https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-List?version=2.0.1). It defines additional rules for use within health and care organisations in Wales.

A direct link to the Data Standards Wales asset can be accessed here - {{link:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-AllergyList}}

### Formal Views of Profile Content
<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink tab-active" onclick="openCity(this,'tabsnap')" data-target="tabsnap">
      Snapshot View
    </li>
    <li class="tablink" onclick="openCity(this,'tabdiff')" data-target="tabdiff">
      Differential View
    </li>
    <li class="tablink" onclick="openCity(this,'tabhybrid')" data-target="tabhybrid">
      Hybrid View
    </li>
    <li class="tablink" onclick="openCity(this,'tabeg')" data-target="tabeg">
      Examples
    </li>    
  </ul>
  <div class="tab-main">
    <div id="tabsnap" class="tabcontent active">      
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-AllergyList, snapshot}}
    </div>
    <div id="tabdiff" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-AllergyList, diff}}
  </div>
    <div id="tabhybrid" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-AllergyList, hybrid}}
  </div>
  <div id="tabeg" class="tabcontent">
    <list>
      <li>{{pagelink:Example-List-Allergies, text:Example List - With allergies}}</li>
      <li>{{pagelink:Example-List-Allergies-notRecorded, text:Example List - Empty list}}</li>
      <li>{{pagelink:Example-List-Allergies-NoKnownAllergy, text:Example List - No known allergies}}</li>
    </list>
  </div>    
</div>

### Mandatory and Must Support Data Elements
Refer to the {{pagelink:Mandatory-and-Must-Support-Data-Elements,text: Mandatory and Must Support}} page for guidance on how these elements should be interpreted.
 
Each Allergy List must have:
1. A status
2. A mode
3. A fixed SNOMED CT code of value of 886921000000105|'Allergies and adverse reactions'
4. A subject (patient)


Each Allergy list must support:
1. An encounter
2. A source to indicate who defined the list contents


The mode is always expected to indicate the list represents a snapshot of an allergy information that is potentially derived from another source.
<br><br>
The `List.code` field **SHALL** be SNOMED CT coded to 'allergies and adverse reactions'.
<br><br>
The resource **SHALL** include a reference to the subject (patient).

### Extensions

The extensions listed below are those created to support Data Standards Wales: 

* {{pagelink:Extension-DataStandardsWales-SingleRecord-AllergiesListConfirmedBy, text:DataStandardsWales-SingleRecord-AllergiesListConfirmedBy}}
is used to provide a reference to the practitioner who confirmed the changes.
* {{pagelink:Extension-DataStandardsWales-SingleRecord-AllergiesListConfirmedDate, text:DataStandardsWales-SingleRecord-AllergiesListConfirmedDate}}
carries a timestamp for when a change has been confirmed.
* {{pagelink:Extension-DataStandardsWales-SingleRecord-AllergiesListUpdated, text:DataStandardsWales-SingleRecord-AllergiesListUpdated}}
is used to provide a boolean on whether the allergies list has been updated.

_Note: this list does not include extensions provided by UK Core and you should refer to their implementation guide for support_





