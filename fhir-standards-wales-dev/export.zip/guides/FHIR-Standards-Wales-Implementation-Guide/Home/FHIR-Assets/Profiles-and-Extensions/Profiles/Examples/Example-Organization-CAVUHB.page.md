## Example Organization - Cardiff and Vale University Local Health Board

The Welsh translation for organisation name and address is derived from Welsh Reference and Terminology Services (WRTS) databases. Please contact <a href="mailto:DHCW.ReferenceDataTeam@wales.nhs.uk?subject=Data%20Standards%20Wales%20FHIR%20implementation%20guide">DHCW.ReferenceDataTeam@wales.nhs.uk</a> for more information

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:Organization/Example-Organization-CAVUHB}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:Organization/Example-Organization-CAVUHB}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:Organization/Example-Organization-CAVUHB}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:Organization/Example-Organization-CAVUHB}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:Organization/Example-Organization-CAVUHB}}
    </div>  
  </div>
</div>