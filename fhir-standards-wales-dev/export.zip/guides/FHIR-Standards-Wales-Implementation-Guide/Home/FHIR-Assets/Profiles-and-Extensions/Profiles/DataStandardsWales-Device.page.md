## {{page-title}}
The [Device](https://www.hl7.org/fhir/r4/device.html) profile captures the type of a manufactured item that is used in the provision of healthcare without being substantially changed through that activity. The device may be a medical or non-medical device.

The {{page-title}} profile is derived from the [HL7 R4 Device](https://www.hl7.org/fhir/r4/device.html). It defines additional rules for use within health and care organisations in Wales.

A direct link to the Data Standards Wales asset can be accessed here - {{link:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Device}}

### Formal Views of Profile Content
<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink tab-active" onclick="openCity(this,'tabsnap')" data-target="tabsnap">
      Snapshot View
    </li>
    <li class="tablink" onclick="openCity(this,'tabdiff')" data-target="tabdiff">
      Differential View
    </li>
    <li class="tablink" onclick="openCity(this,'tabhybrid')" data-target="tabhybrid">
      Hybrid View
    </li>
    <li class="tablink" onclick="openCity(this,'tabeg')" data-target="tabeg">
      Examples
    </li>    
  </ul>
  <div class="tab-main">
    <div id="tabsnap" class="tabcontent active">      
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Device, snapshot}}
    </div>
    <div id="tabdiff" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Device, diff}}
  </div>
    <div id="tabhybrid" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Device, hybrid}}
  </div>
  <div id="tabeg" class="tabcontent">
      <list>
      <li>{{pagelink:Example-DataStandardsWales-Device-CDRcomponent, text:CDR Component}}</li>
      <li>{{pagelink:Example-DataStandardsWales-Device-WPAS, text:Device - WPAS}}</li>
    </list>
  </div>
</div>

### Mandatory and Must Support Data Elements

Refer to the {{pagelink:Mandatory-and-Must-Support-Data-Elements,text: Mandatory and Must Support}} page for guidance on how these elements should be interpreted.

Each Device must support:

* An identifier of type applicationInstanceId
* A device status
* A device type


### Slice
The following identifier slice is to be used with the device profile is listed below. 
 
* `Device.identifier:applicationInstanceId` 