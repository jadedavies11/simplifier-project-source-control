## {{page-title}}
The [DocumentReference](https://www.hl7.org/fhir/r4/documentreference.html) resource profile is used to index a document, clinical note, or other binary object to make them available to a healthcare system. A document is some sequence of bytes that is identifiable, establishes its own context (e.g., what subject, author, etc. can be displayed to the user), and has defined update management. The DocumentReference resource can be used with any document format that has a recognized MIME type and that conforms to this definition.

The {{page-title}} profile is derived from the [HL7 R4 DocumentReference](https://www.hl7.org/fhir/r4/documentreference.html). It defines additional rules for use within health and care organisations in Wales.

A direct link to the Data Standards Wales asset can be accessed here - {{link:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-DocumentReference}}

### Formal Views of Profile Content
<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink tab-active" onclick="openCity(this,'tabsnap')" data-target="tabsnap">
      Snapshot View
    </li>
    <li class="tablink" onclick="openCity(this,'tabdiff')" data-target="tabdiff">
      Differential View
    </li>
    <li class="tablink" onclick="openCity(this,'tabhybrid')" data-target="tabhybrid">
      Hybrid View
    </li>
    <li class="tablink" onclick="openCity(this,'tabeg')" data-target="tabeg">
      Examples
    </li>    
  </ul>
  <div class="tab-main">
    <div id="tabsnap" class="tabcontent active">      
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-DocumentReference, snapshot}}
    </div>
    <div id="tabdiff" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-DocumentReference, diff}}
  </div>
    <div id="tabhybrid" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-DocumentReference, hybrid}}
  </div>
  <div id="tabeg" class="tabcontent">
    <list>
      <li>{{pagelink:Example-DataStandardsWales-DocumentReference-EncounterBased, text: Example Document Reference - Encounter-based}}</li>
      <li>{{pagelink:Example-DataStandardsWales-DocumentReference-EventBased, text: Example Document Reference - Event-based}}</li>
      <li>{{pagelink:Example-DataStandardsWales-DocumentReference-NotEventBased, text: Example Document Reference - Not event-based}}</li>
      <li>{{pagelink:Example-DataStandardsWales-DocumentReference-ExpiredInsuranceCover, text:Example Document Reference - Expired Insurance Cover}}</li>
      <li>{{pagelink:Example-DataStandardsWales-Encounter-DocumentedEvent-DiabetesConsultation, text:Example Encounter - Documented Event (Diabetes Consultation)}}</li>
      <li>{{pagelink:Example-DataStandardsWales-Bundle-CareDocumentSubmit-CDR, text:Example Message Bundle - Care Document Submit (Minimal Required CDR Data)}}</li>
      <li>{{pagelink:Example-DataStandardsWales-DocumentReference-PotentiallyMisfiled, text: Example Document Reference - Potentially Misfiled}}</li>
      <li>{{pagelink:Example-DataStandardsWales-DocumentReference-MisfileRejected, text: Example Document Reference - Misfile Rejected}}</li>
      <li>{{pagelink:Example-DataStandardsWales-DocumentReference-Misfiled, text: Example Document Reference - Misfiled}}</li>
    </list>
  </div>  
</div>

### Mandatory and Must Support Data Elements
Refer to the {{pagelink:Mandatory-and-Must-Support-Data-Elements,text: Mandatory and Must Support}} page for guidance on how these elements should be interpreted.
 
Each DocumentReference must have:
1. A status
1. A digital status
1. A type
1. One or more categories
1. One or more attachments as *either* a base 64 binary *or* a URL. 

Each DocumentReference must support:
1. One or more identifiers
1. A document status
1. A subject
1. A date
1. One or more authors
1. One or more attesters
1. A custodian
1. One or more security labels
1. A practice setting
1. A source system, identified in the `meta.source` element
1. A version
<br>

The `DocumentReference.status` field **SHALL** be populated with with one of the following values defined by the FHIR standard:
- current
- superseded
- entered-in-error
<br>

The `DocumentReference.extension:digitalStatus` field **SHALL** be populated with with one of the following values defined by the FHIR standard:
- born-digital-document
- scanned-paper-document
- UNK
<br>

### Extensions
The extensions listed below allow a number of the data elements listed above to be supported where not currently supported by the FHIR standard:
  * Data Standards Wales extensions
    * {{pagelink:Extension-DataStandardsWales-DocumentDigitalStatus}} supports the capture of a mandatory indication of whether the document was born digital or scanned.

  * Backport extensions 
    * The following extensions are based on elements in the [HL7 R5 DocumentReference](https://www.hl7.org/fhir/r5/documentreference.html) resource definition. See {{pagelink:Home/Help-and-Support/Deployment.page.md}} for more information on dependencies.
      * **ExtensionDocumentReference_Attester** supports the identification of the person or entity that attested to the accuracy of the document. It is based on `DocumentReference.attester` in R5.
      * **ExtensionDocumentReference_Version** supports the capture of an explicitly assigned identifer of a variation of the content in the DocumentReference. It is based on `DocumentReference.version` in R5.