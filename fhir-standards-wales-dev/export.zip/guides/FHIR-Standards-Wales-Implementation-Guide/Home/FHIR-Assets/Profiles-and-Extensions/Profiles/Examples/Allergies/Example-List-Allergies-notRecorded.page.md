## Example Allergy List - Empty list

This example references the following example resources:

* Subject, source and context:
  * {{pagelink:Example-Patient-AliceJones, text:Example Patient - Alice Jones}}
  * {{pagelink:Example-Practitioner-Consultant, text:Example Practitioner - Dhiren Patel (Consultant)}}


<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:List/Example-List-Allergies-NotRecorded}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:List/Example-List-Allergies-NotRecorded}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:List/Example-List-Allergies-NotRecorded}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:List/Example-List-Allergies-NotRecorded}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:List/Example-List-Allergies-NotRecorded}}
    </div>  
  </div>
</div>