## AllergyIntolerance - Medication (ibuprofen)
This shows an example medication allergy.

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:AllergyIntolerance/Example-AllergyIntolerance-Ibuprofen}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:AllergyIntolerance/Example-AllergyIntolerance-Ibuprofen}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:AllergyIntolerance/Example-AllergyIntolerance-Ibuprofen}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:AllergyIntolerance/Example-AllergyIntolerance-Ibuprofen}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:AllergyIntolerance/Example-AllergyIntolerance-Ibuprofen}}
    </div>  
  </div>
</div>