<p>The following Profiles have been defined for this Implementation Guide and listed alphabetically.</p>
<p>All derivations whether HL7 FHIR International, HL7 FHIR UK Core or Data Standards Wales are based on the R4 release.</p>

<style>
  th, td {
    word-wrap: break-word;
    white-space: normal;
  }
</style>

<table class="table table-striped" style="table-layout: fixed;">
  <colgroup>
    <col style="width: 42%;">
    <col style="width: 40%;">
    <col style="width: 8%;">
	<col style="width: 10%;">
  </colgroup>

<thead>
	<tr>
		<th scope="col">Profile</th>
		<th scope="col">Derived from</th>
		<th scope="col">Status</th>
		<th scope="col">Asset Version</th>
	</tr>
</thead>
<tbody>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-AllergyIntolerance}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-AllergyIntolerance?version=2.0.1">UKCore-AllergyIntolerance</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-AllergyList}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-List?version=2.0.1">UKCore-List</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Appointment}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-Appointment?version=2.0.1">UKCore-Appointment</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-AuditEvent}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/r4/auditevent.html">AuditEvent</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Composition}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-Composition?version=2.0.1">UKCore-Composition</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Condition}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-Condition?version=2.0.1">UKCore-Condition</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.1.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Consent}}</td>
		<td>
			<a href="https://hl7.org/fhir/R4/consent.html">Consent</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.0.3</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Device}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/r4/device.html">Device</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DiagnosticReport}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-DiagnosticReport?version=2.0.1">UKCore-DiagnosticReport</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DiagnosticReport-Lab}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-DiagnosticReport-Lab?version=2.0.1">UKCore-DiagnosticReport-Lab</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/r4/documentreference.html">DocumentReference</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-Encounter?version=2.0.1">UKCore-Encounter</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.3</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>{{pagelink:DataStandardsWales-Encounter, text: DataStandardsWales-Encounter}}</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.1.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Endpoint}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/r4/Endpoint.html">Endpoint</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-ImagingStudy}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/r4/ImagingStudy.html">ImagingStudy</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Immunization}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-Immunization?version=2.0.1">UKCore-Immunization</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.3.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-ImmunizationRecommendation}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/r4/immunizationrecommendation.html">ImmunizationRecommendation</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Location}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-Location?version=2.0.1">UKCore-Location</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Medication}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-Medication?version=2.0.1">UKCore-Medication</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MedicationAdministration}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-MedicationAdministration?version=2.0.1">UKCore-MedicationAdministration</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MedicationDispense}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-MedicationDispense?version=2.0.1">UKCore-MedicationDispense</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MedicationList}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-List?version=2.0.1">UKCore-List</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MedicationRequest}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-MedicationRequest?version=2.0.1">UKCore-MedicationRequest</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.3.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MedicationStatement}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-MedicationStatement?version=2.0.1">UKCore-MedicationStatement</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MessageDefinition}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/R4/messagedefinition.html">MessageDefinition</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.0.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MessageHeader}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/R4/messageheader.html">MessageHeader</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.0.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-Observation?version=2.0.1">UKCore-Observation</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-Lab}}</td>
		<td>{{pagelink:DataStandardsWales-Observation, text: DataStandardsWales-Observation}}</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns}}</td>
		<td>{{pagelink:DataStandardsWales-Observation, text: DataStandardsWales-Observation}}</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns, text: DataStandardsWales-Observation-VitalSigns}}</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns, text: DataStandardsWales-Observation-VitalSigns}}</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns, text: DataStandardsWales-Observation-VitalSigns}}</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Organization}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-Organization?version=2.0.1">UKCore-Organization</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Patient}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-Patient?version=2.0.1">UKCore-Patient</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.2</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Practitioner}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-Practitioner?version=2.0.1">UKCore-Practitioner</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.2.0</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-PractitionerRole}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-PractitionerRole?version=2.0.1">UKCore-PractitionerRole</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.3</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Provenance}}</td>
		<td>
			<a href="https://www.hl7.org/fhir/r4/provenance.html">Provenance</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Questionnaire}}</td>
		<td>
			<a href="https://hl7.org/fhir/R4/questionnaire.html">Questionnaire</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-QuestionnaireResponse}}</td>
		<td>
			<a href="https://hl7.org/fhir/R4/questionnaireresponse.html">QuestionnaireResponse</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-RelatedPerson}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-RelatedPerson?version=2.0.1">UKCore-RelatedPerson</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.0.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-ServiceRequest}}</td>
		<td>
			<a href="https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-ServiceRequest?version=2.0.1">UKCore-ServiceRequest</a>
		</td>
		<td><a class="tagactive" target="_blank">Active</a></td>
		<td>1.1.1</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Specimen}}</td>
		<td>
			<a href="https://simplifier.net/guide/uk-core-implementation-guide-stu2/Home/ProfilesandExtensions/Profile-UKCore-Specimen?version=2.0.1">UKCore-Specimen</a>
		</td>
		<td><a class="tagdraft" target="_blank">Draft</a></td>
		<td>0.2.1</td>
	</tr>
</tbody>
</table>