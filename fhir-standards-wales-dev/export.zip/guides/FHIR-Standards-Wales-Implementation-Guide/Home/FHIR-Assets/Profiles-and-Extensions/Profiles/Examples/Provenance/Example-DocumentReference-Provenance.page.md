## Example Document Reference - Provenance-related HL7v2 message
This DocumentReference example is used in conjuction with the {{pagelink:Example-Provenance-DemographicUpdate, text: Provenance}} example and shows how provenance can be linked to the message that triggered the insert or update to the record e.g. an HL7v2 ADT^A31 demographic update message.

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:DocumentReference/Example-DocumentReference-Provenance}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:DocumentReference/Example-DocumentReference-Provenance}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:DocumentReference/Example-DocumentReference-Provenance}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:DocumentReference/Example-DocumentReference-Provenance}}
    </div>        
  </div>
</div>