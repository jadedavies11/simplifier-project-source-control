### {{page-title}}

The following ValueSets containing SNOMED CT codes.

<style>
  th, td {
    word-wrap: break-word;
    white-space: normal;
  }
</style>

<table class="table table-striped" style="table-layout: fixed;">
  <colgroup>
    <col style="width: 26%;">
    <col style="width: 26%;">
    <col style="width: 26%;">
	<col style="width: 20%;">
  </colgroup>

  <thead>
    <tr>
      <th scope="col">ValueSet</th>
      <th scope="col">Bound to Profile</th>
      <th scope="col">Bound to Element</th>
	  <th scope="col">Additional Information</th>
    </tr>
	</thead>
	<tbody>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BloodPressure-AverageSystolic, text: DataStandardsWales-BloodPressure-AverageSystolic}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BloodPressure-Diastolic, text: DataStandardsWales-BloodPressure-Diastolic}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BloodPressure-Systolic, text: DataStandardsWales-BloodPressure-Systolic}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BMI, text: DataStandardsWales-BMI}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</td>
		<td>Observation.code.coding:snomedCT</td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BodyHeightMeasurements, text: DataStandardsWales-BodyHeightMeasurements}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</td>
		<td>Observation.code.coding:snomedCT</td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text: DataStandardsWales-BodyPosition}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns}}</td>
		<td>Observation.extension:bodyPosition</td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text: DataStandardsWales-BodyPosition}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</td>
		<td>Observation.extension:bodyPosition</td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text: DataStandardsWales-BodyPosition}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</td>
		<td>Observation.extension:bodyPosition</td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text: DataStandardsWales-BodyPosition}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</td>
		<td>Observation.extension:bodyPosition</td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BodyTemperature, text: DataStandardsWales-BodyTemperature}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
		<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-BodyWeightMeasurements, text: DataStandardsWales-BodyWeightMeasurements}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</td>
		<td>Observation.code.coding:snomedCT</td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-DocumentType, text: DataStandardsWales-DocumentType}}</td>
		<td>{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>DocumentReference.type</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-EncounterType, text: DataStandardsWales-EncounterType}}</td>
		<td>{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>Encounter.type</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-HeadCircumferenceMeasurements, text: DataStandardsWales-HeadCircumferenceMeasurements}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-HeartRate, text: DataStandardsWales-HeartRate}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns}}</td>
		<td>Observation.code.coding:snomedCT</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns}}</td>
		<td>Observation.component.code</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns}}</td>
		<td>Observation.component.code.coding:snomedCT</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</td>
		<td>Observation.component.code</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</td>
		<td>Observation.component.code.coding:snomedCT</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</td>
		<td>Observation.component.code</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</td>
		<td>Observation.component.code.coding:snomedCT</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</td>
		<td>Observation.component.code</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType, text: DataStandardsWales-ObservationVitalSignsType}}</td>
		<td>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</td>
		<td>Observation.component.code.coding:snomedCT</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-Occupation, text: DataStandardsWales-Occupation}}</td>
		<td>{{pagelink:DataStandardsWales-Patient}}</td>
		<td>Patient.extension:occupation</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-OxygenSaturation, text: DataStandardsWales-OxygenSaturation}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-Religion, text: DataStandardsWales-Religion}}</td>
		<td>{{pagelink:DataStandardsWales-Patient}}</td>
		<td>Patient.extension:religion</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-RespirationRate, text: DataStandardsWales-RespirationRate}}</td>
		<td></td>
		<td></td>
		<td>Embedded in {{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-UEC-Acuity, text: DataStandardsWales-UEC-Acuity}}</td>
		<td>{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>Encounter.priority</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-UEC-ArrivalMode, text: DataStandardsWales-UEC-ArrivalMode}}</td>
		<td>{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>Encounter.extension:modeOfArrival</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-UEC-AttendanceSource, text: DataStandardsWales-UEC-AttendanceSource}}</td>
		<td>{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>Encounter.hospitalization.admitSource</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-DataStandardsWales-UEC-DischargeDestination, text: DataStandardsWales-UEC-DischargeDestination}}</td>
		<td>{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>Encounter.hospitalization.dischargeDisposition</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:ValueSet-PASReferralSource, text: PASReferralSource}}</td>
		<td></td>
		<td></td>
		<td>Not bound to profile</td>
	</tr>
	</tbody>
</table>