### {{page-title}}

This is a list of Data Standards Wales profiles with local extensions to be used in NHS Wales.


<style>
  th, td {
    word-wrap: break-word;
    white-space: normal;
  }
</style>

<table class="table table-striped" style="table-layout: fixed;">
  <colgroup>
    <col style="width: 16%;">
    <col style="width: 20%;">
    <col style="width: 25%;">
    <col style="width: 28%;">
    <col style="width: 11%;">
  </colgroup>

  <thead>
    <tr>
      <th scope="col">Profile</th>
      <th scope="col">Extension</th>
      <th scope="col">Bound to Profile Element</th>
      <th scope="col">ValueSet & CodeSystem</th>
      <th scope="col">Backported</th>
    </tr>
	</thead>
	<tbody>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-AllergyList}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-SingleRecord-AllergiesListConfirmedBy, text:DataStandardsWales-SingleRecord-AllergiesListConfirmedBy}}</td>
		<td>extension:SingleRecordAllergiesListConfirmedBy</td>
		<td></td>
		<td></td>
	</tr>	
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-AllergyList}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-SingleRecord-AllergiesListConfirmedDate, text:DataStandardsWales-SingleRecord-AllergiesListConfirmedDate}}</td>
		<td>extension:SingleRecordAllergiesListConfirmedDate</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-AllergyList}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-SingleRecord-AllergiesListUpdated, text:DataStandardsWales-SingleRecord-AllergiesListUpdated}}</td>
		<td>extension:SingleRecordAllergiesListUpdated</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Appointment}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-ClinicCode, text:DataStandardsWales-ClinicCode}}</td>
		<td>extension:clinicCode</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DocumentAttester, text:DataStandardsWales-DocumentAttester}}</td>
		<td>extension:attesterR5</td>
		<td>
			<a href="https://hl7.org/fhir/valueset-composition-attestation-mode.html">composition-attestation-mode</a><br>
			<a href="https://hl7.org/fhir/codesystem-composition-attestation-mode.html">composition-attestation-mode</a>
		</td>
		<td>R5</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DocumentAttribute, text:DataStandardsWales-DocumentAttribute}}</td>
		<td>extension:documentAttribute</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-DocumentAttribute, text:DataStandardsWales-DocumentAttribute}}<br>
		{{pagelink:CodeSystem-DataStandardsWales-DocumentAttribute, text:DataStandardsWales-DocumentAttribute}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DocumentDigitalStatus, text:DataStandardsWales-DocumentDigitalStatus}}</td>
		<td>extension:digitalStatus</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-DocumentDigitalStatus, text:DataStandardsWales-DocumentDigitalStatus}}<br>
		{{pagelink:CodeSystem-DataStandardsWales-DocumentDigitalStatus, text:DataStandardsWales-DocumentDigitalStatus}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DocumentErrorAction, text:DataStandardsWales-DocumentErrorAction}}</td>
		<td>extension:errorAction</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-DocumentErrorAction, text:DataStandardsWales-DocumentErrorAction}}<br>{{pagelink:CodeSystem-DataStandardsWales-DocumentErrorAction, text:DataStandardsWales-DocumentErrorAction}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DocumentErrorStatus, text:DataStandardsWales-DocumentErrorStatus}}</td>
		<td>extension:errorStatus</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-DocumentErrorStatus, text:DataStandardsWales-DocumentErrorStatus}}<br>{{pagelink:CodeSystem-DataStandardsWales-DocumentErrorStatus, text:DataStandardsWales-DocumentErrorStatus}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DocumentVersion, text:DataStandardsWales-DocumentVersion}}</td>
		<td>extension:versionR5</td>
		<td></td>
		<td>R5</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-DocumentReference}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-SourceSystem, text:DataStandardsWales-SourceSystem}}</td>
		<td>extension:sourceSystem</td>
		<td></td>
		<td></td>
	</tr>
		<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-Speciality, text:DataStandardsWales-Speciality}}</td>
		<td>extension:Speciality</td>
		<td>
			<a href="https://simplifier.net/packages/fhir.r4.ukcore.stu2/2.0.1/files/2483924">UKCore-PracticeSettingCode</a><br>
			<a href="https://simplifier.net/packages/fhir.r4.ukcore.stu2/2.0.1/files/2483923">UKCore-PracticeSettingCode</a>
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-Speciality, text:DataStandardsWales-Speciality}}</td>
		<td>extension:Speciality</td>
		<td>
			<a href="https://simplifier.net/packages/fhir.r4.ukcore.stu2/2.0.1/files/2483924">UKCore-PracticeSettingCode</a><br>
			<a href="https://simplifier.net/packages/fhir.r4.ukcore.stu2/2.0.1/files/2483923">UKCore-PracticeSettingCode</a>
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-UECAttendanceCategory, text:DataStandardsWales-UEC-AttendanceCategory}}</td>
		<td>Encounter.extension:uecAttendanceCategory</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-UEC-AttendanceCategory, text:DataStandardsWales-UEC-AttendanceCategory}}<br>
		{{pagelink:CodeSystem-DataStandardsWales-UEC-AttendanceCategory, text:DataStandardsWales-UEC-AttendanceCategory}}
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-UECDischargeInformationGiven, text:DataStandardsWales-UEC-DischargeInformationGiven}}</td>
		<td>extension:uecDischargeInformationGiven</td>
		<td></td>	
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter-UEC}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-UECExpectedTimeOfTreatment, text:DataStandardsWales-UEC-ExpectedTimeOfTreatment}}</td>
		<td>extension:uecExpectedTimeOfTreatment</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Encounter-UEC}}</td>	
		<td>
			<a href="https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1/files/2998643">modeOfArrival</a>
		</td>
		<td>extension:modeOfArrival</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-UEC-ArrivalMode, text:DataStandardsWales-UEC-ArrivalMode}}<br>
		&nbsp;SNOMED CT	
		</td>	
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Immunization}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-AdministeredProduct, text:DataStandardsWales-AdministeredProduct}}</td>
		<td>extension:administeredProduct</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Immunization}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DateProcedureLastUpdated, text:DataStandardsWales-DateProcedureLastUpdated}}</td>
		<td>extension:dateProcedureLastUpdated</td>
		<td></td>
		<td></td>
	</tr>	
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Immunization}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-ForecastCreationSource, text:DataStandardsWales-ForecastCreationSource}}</td>
		<td>extension:forecastCreationSource</td>
		<td></td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Immunization}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-Immunization.basedOn, text:DataStandardsWales-Immunization.basedOn}}</td>
		<td>extension:immunizationBasedOnR5</td>
		<td></td>
		<td>R5</td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-MedicationStatement}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-MedicationCourseOfTherapyType, text:DataStandardsWales-MedicationCourseOfTherapyType}}</td>
		<td>extension:medicationCourseOfTherapyType</td>
		<td>
			<a href="https://terminology.hl7.org/7.0.1/ValueSet-medicationrequest-course-of-therapy.html">Medication request course of therapy codes</a><br>
			<a href="https://terminology.hl7.org/7.0.1/CodeSystem-medicationrequest-course-of-therapy.html">MedicationRequest Course of Therapy Codes</a>
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-RecordingSetting, text:DataStandardsWales-RecordingSetting}}</td>
		<td>extension:recordingSetting</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}<br>
		{{pagelink:CodeSystem-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns}}</td>
		<td>	
			<a href="https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1/files/2999538">bodyPosition</a>
		</td>
		<td>extension:bodyPosition</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text:DataStandardsWales-BodyPosition}}<br>
		&nbsp;SNOMED CT
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-RecordingSetting, text:DataStandardsWales-RecordingSetting}}</td>
		<td>extension:recordingSetting</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}<br>
		{{pagelink:CodeSystem-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</td>
		<td>	
			<a href="https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1/files/2999538">bodyPosition</a>
		</td>
		<td>extension:bodyPosition</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text:DataStandardsWales-BodyPosition}}<br>
		&nbsp;SNOMED CT
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-RecordingSetting, text:DataStandardsWales-RecordingSetting}}</td>
		<td>extension:recordingSetting</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}<br>
		{{pagelink:CodeSystem-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</td>
		<td>	
			<a href="https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1/files/2999538">bodyPosition</a>
		</td>
		<td>extension:bodyPosition</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text:DataStandardsWales-BodyPosition}}<br>
		&nbsp;SNOMED CT
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-RecordingSetting, text:DataStandardsWales-RecordingSetting}}</td>
		<td>extension:recordingSetting</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}<br>
		{{pagelink:CodeSystem-DataStandardsWales-RecordingSetting,text:DataStandardsWales-RecordingSetting}}</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</td>
		<td>	
			<a href="https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1/files/2999538">bodyPosition</a>
		</td>
		<td>extension:bodyPosition</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-BodyPosition, text:DataStandardsWales-BodyPosition}}<br>
		&nbsp;SNOMED CT
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Patient}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-Occupation, text:DataStandardsWales-Occupation}}</td>
		<td>extension:occupation</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-Occupation, text:DataStandardsWales-Occupation}}<br>
		&nbsp;SNOMED CT
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Patient}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-Religion, text:DataStandardsWales-Religion}}</td>
		<td>Patient.extension:religion</td>
		<td>{{pagelink:ValueSet-DataStandardsWales-Religion, text:DataStandardsWales-Religion}}<br>
		&nbsp;SNOMED CT
		</td>
		<td></td>
	</tr>
	<tr>
		<td scope="row">{{pagelink:DataStandardsWales-Provenance}}</td>
		<td>{{pagelink:Extension-DataStandardsWales-DemographicsAsRecorded, text:DataStandardsWales-DemographicsAsRecorded}}</td>
		<td>extension:extensionDataStandardsWalesDemographicsAsRecorded</td>
		<td>
			<a href="https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1/files/3001742">AdministrativeGender</a><br>
			<a href="https://simplifier.net/packages/hl7.fhir.r4.core/4.0.1/files/3001376">AdministrativeGender</a>
		</td>
		<td></td>
	</tbody>
</table>