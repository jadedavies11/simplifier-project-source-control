<div class="warning"><span class="ImplementWarn"></span></div>

{{render:https://fhir.nhs.wales/ValueSet/PASEventType, text:PASEventType}}

This snapshot of the PAS Event Type ValueSet is not owned nor managed by Data Standards Team or the FHIR Service. 