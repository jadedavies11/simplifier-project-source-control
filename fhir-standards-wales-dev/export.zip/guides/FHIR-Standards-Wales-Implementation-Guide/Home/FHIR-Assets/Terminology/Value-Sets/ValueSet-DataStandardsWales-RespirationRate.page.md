<div class="warning"><span class="ImplementWarn"></span></div>

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-RespirationRate, text:DataStandardsWales-RespirationRate}}