<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

Only a sample of the value set has been shown. To obtain the full list, please contact the Welsh Reference & Terminology Service by email:
<a href="mailto:DHCW.ReferenceDataTeam@wales.nhs.uk?subject=Data%20Standards%20Wales%20FHIR%20implementation%20guide">DHCW.ReferenceDataTeam@wales.nhs.uk</a>

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-DocumentType, text:DataStandardsWales-DocumentType}}