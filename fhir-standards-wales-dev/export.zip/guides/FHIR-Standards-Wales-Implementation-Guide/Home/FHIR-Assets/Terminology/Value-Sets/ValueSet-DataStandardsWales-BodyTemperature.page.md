<div class="warning"><span class="ImplementWarn"></span></div>

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-BodyTemperature, text:DataStandardsWales-BodyTemperature}}