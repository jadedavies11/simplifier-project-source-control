<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-DocumentCategory, text:DataStandardsWales-DocumentCategory}}