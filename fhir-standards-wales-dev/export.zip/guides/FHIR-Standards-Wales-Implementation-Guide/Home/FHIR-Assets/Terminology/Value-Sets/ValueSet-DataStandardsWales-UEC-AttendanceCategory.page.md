<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-UEC-AttendanceCategory, text:DataStandardsWales-UEC-AttendanceCategory}}