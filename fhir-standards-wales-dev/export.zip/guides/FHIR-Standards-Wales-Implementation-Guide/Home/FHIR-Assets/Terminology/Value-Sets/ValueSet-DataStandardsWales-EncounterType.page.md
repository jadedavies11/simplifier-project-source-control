<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

This Value Set is based on UK Core Encounter Type with additional codes from Data Standards Wales UEC Care Consultation Mechanism and Data Standards Wales UEC Activity Type.

Only a sample of the value set has been shown. To obtain the full list, please contact the Welsh Reference & Terminology Service by email:
<a href="mailto:DHCW.ReferenceDataTeam@wales.nhs.uk?subject=Data%20Standards%20Wales%20FHIR%20implementation%20guide">DHCW.ReferenceDataTeam@wales.nhs.uk</a>

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-EncounterType, text:DataStandardsWales-EncounterType}}

