<div class="warning"><span class="ImplementWarn"></span></div>

This Value Set is based on UK Core Encounter Type with additional codes from Data Standards Wales UEC Care Consultation Mechanism and Data Standards Wales UEC Activity Type.

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-EncounterType, text:DataStandardsWales-EncounterType}}

