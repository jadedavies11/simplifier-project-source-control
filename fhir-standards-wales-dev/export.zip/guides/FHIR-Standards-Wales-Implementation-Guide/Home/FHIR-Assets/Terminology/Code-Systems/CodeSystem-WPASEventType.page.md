<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

This snapshot of the PAS Event Type CodeSystem is not owned nor managed by Data Standards Team or the FHIR Service. 

{{render:https://fhir.nhs.wales/CodeSystem/WPASEventType}}

