<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

This CodeSystem indicates the mechanism of the consultation. 

{{render:https://fhir.nhs.wales/CodeSystem/DataStandardsWales-UEC-CareConsultationMechanism}}

