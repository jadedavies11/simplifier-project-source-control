<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

WPAS Referral Source CodeSystem is owned and managed by Digital Health and Care Wales WPAS. These are not a data standard and this snapshot is for example use only. 

{{render:https://fhir.nhs.wales/CodeSystem/WPASReferralSource}}

