<b>Filename structure:</b> <span style="color:#0070c0;">[Example]-</span><span style="color:#914829;">[L3L4ResourceType]-</span><span style="color:#c00000;">[Descriptor]</span><span style="color:#7030a0;">{-[Qualifier]}</span><br />
<b>id structure:</b> <span style="color:#0070c0;">[Example]-</span><span style="color:#914829;">[L3L4ResourceType]-</span><span style="color:#c00000;">[Descriptor]</span><span style="color:#7030a0;">{-[Qualifier]}</span><br /><br />
​
<b><i>Worked example 1​</i></b><br />
<span style="font-size: 0.9em;">An example Organization resource for Neath Port Talbot Hospital.</span>

<table class="table properties-table">
	<tbody>
		<tr>
			<th scope="row">Asset filename</th>
			<td>Example-Organization-NPT.xml</td>
		</tr>
		<tr>
			<th scope="row">Page filename</th>
			<td>Example-Organization-NPT.page.md</td>
		</tr>
		<tr>
			<th scope="row">id</th>
			<td>Example-Organization-NPT</td>
		</tr>
		<tr>
			<th scope="row">reference</th>
			<td>Organization/Example-Organization-NPT</td>
		</tr>
    </tbody>
</table>

<b><i>Worked example 2​</i></b><br />
<span style="font-size: 0.9em;">An example MedicationStatement resource for Bendroflumethiazide issued at the point of discharge.</span>

<table class="table properties-table">
	<tbody>
		<tr>
			<th scope="row">Asset filename</th>
			<td>Example-MedicationStatement-Bendroflumethiazide-Discharge.xml</td>
		</tr>
		<tr>
			<th scope="row">Page filename</th>
			<td>Example-MedicationStatement-Bendroflumethiazide-Discharge.page.md</td>
		</tr>
		<tr>
			<th scope="row">id</th>
			<td>Example-MedicationStatement-Bendroflumethiazide-Discharge</td>
		</tr>
		<tr>
			<th scope="row">reference</th>
			<td>MedicationStatement/Example-MedicationStatement-Bendroflumethiazide-Discharge</td>
		</tr>
    </tbody>
</table>