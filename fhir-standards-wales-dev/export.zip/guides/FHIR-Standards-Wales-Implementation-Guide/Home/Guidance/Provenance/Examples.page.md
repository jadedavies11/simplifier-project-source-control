## {{page-title}}
The following examples are based on the model above:
* {{pagelink:Example-Provenance-DemographicUpdate, text: Example Provenance - Demographics update as result of an HL7v2 patient demographic update}}
    * {{pagelink:Example-Device-WPAS, text: Device (Welsh PAS)}}
	* {{pagelink:Example-Device-CDRcomponent, text: Device (component of CDR)}}
	* {{pagelink:Example-DocumentReference-Provenance, text: DocumentReference (Provenance-related HL7v2 message)}}

The use of the Provenance resource to capture the subject demographics at the time of an Observation is illustrated by the following example:
* {{pagelink:Example-Provenance-DemographicsAsRecorded, text: Example Provenance - Demographics as Recorded extension usage}}