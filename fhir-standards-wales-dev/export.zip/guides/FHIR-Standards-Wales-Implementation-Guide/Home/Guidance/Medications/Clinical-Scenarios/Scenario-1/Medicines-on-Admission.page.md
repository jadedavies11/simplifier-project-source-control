### 3) Medicines on admission 
{{pagelink:Example-List-Medications-Admission, text: Example list of medications based on the following medications as recorded on the patient's admission to hospital}}

#### From GP data

* Bendroflumethiazide 2.5mg tablets – 1 tablet every morning
* Bisoprolol 1.25mg tablets – 1 tablet every morning  
* Nifedipress MR 20mg tablet 1 tablet twice a day  
* Ramipril 2.5mg tablet – 1 tablet in the morning  
* Atorvastatin 20mg tablet – 1 tablet at night  
* Durogesic DTrans 25 microgram/hour transdermal patches – Apply one patch every 72 hours 
* Hydrocortisone 1% Cream – Apply to the affected area twice a day  
* Latanoprost 50micrograms/ml eye drops 0.2ml unit dose preservative free – Instil one drop into the left eye at night  

#### From Rheumatology Clinic 
* Enbrel (Etanercept) 50mg/1ml solution for injection pre-filled syringes, Inject 50mg subcutaneously once a week _(Note: prescribed by brand (AMP level) as it’s a biologic)_

#### Patient self-medication
_Information provided by the patient verbally during admission._
* Ibuprofen 200mg tablets, 2-3 tablets three times a day 
* Paracetamol 500mg tablets 2 tablets four times a day 