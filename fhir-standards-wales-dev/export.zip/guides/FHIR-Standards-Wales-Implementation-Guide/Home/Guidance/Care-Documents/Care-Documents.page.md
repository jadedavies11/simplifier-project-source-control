# Care Documents
<div style="float:right;border:1px;border-style:solid;padding:10px;margin:10px;width:300px;">

  - [Data Model Overview](#data-model-overview)
  - [FHIR Resources](#fhir-resources)
    * [Device](#device)
    * [DocumentReference](#documentreference)
    * [Encounter](#encounter)
    * [Location](#location)
    * [Organization](#organization)
    * [Patient](#patient)
    * [PractitionerRole](#practitionerrole)
    * [Provenance](#provenance)
    * [RelatedPerson](#relatedperson)
  - [Supporting Legacy Metadata](#supporting-legacy-metadata)
  - [Clinical Scenarios / Examples](#clinical-scenarios-examples)
    * [Encounter-based Document](#encounter-based-document)
    * [Event-based Document](#event-based-document)
    * [Document not Event-based](#document-not-event-based)
    * [Examples](#examples)
  - [Document Error Workflow](#document-error-workflow)
    * [Misfiling Workflow](#misfiling-workflow)
    * [Revocation Workflow](#revocation-workflow)
  - [Care Document Versions](#care-document-versions)
    * [How versioning works in WCRS](#how-versioning-works-in-wcrs)
    * [How versioning works in FHIR](#how-versioning-works-in-fhir)
    * [Minimising disruption during transition](#minimising-disruption-during-transition)
</div>

*The scope of this guidance is the storage of metadata for documents related to the care of individual patients as part of their individual health care records.*

## Context of Use
These examples represent a logical data model of Care Documents within the national architecture. They are NOT a physical data model, and make no assumptions about the behaviours of a given FHIR Server or Client in response to a given operation, including sending or querying. Please ensure that you have queried the Capability Statement of your target FHIR Server or Client for a statement of actual server functionality or a statement of required or desired server implementation.

The elements of this logical data model which are illustrated by examples include valid payloads of data within Data Standards Wales FHIR Profiles. They are intended to provide a point of comparison to your own testing data, or for use within testing, either to quickly fill out a submission to a FHIR Server, or as contents for a server to be queried. Whilst these examples feature all mandatory and must support data elements, data is not supplied for every other possible element of a profile. Both validations and operations may fail in target FHIR servers without supporting data in the submission.

Not all operations will require the use of all of the example FHIR profiles and data items provided. For modifications to these examples, or support with additional examples and test scenarios, please contact {{pagelink:Help-and-Support, text:the FHIR Standards Development Team}} directly.

## Data Model Overview
This section of the guidance illustrates how a currently valid care document may be represented by resources within a FHIR datastore, including any Provenance resources generated for the document submission at the point of insertion. It does not cover any additional resource instances associated with documents considered to be invalid or untrustworthy.  See the [Document Error Workflow](#document-error-workflow) section below for details.

The metadata associated with patient care documents will be stored as a dedicated DocumentReference resource and, where appropriate, as a linked Encounter resource that carries clinical data for the documented event. Many aspects of the metadata will be achieved through referencing of pre-existing administrative entities such as Location, Organization and PractitionerRole. The creation or update of a DocumentReference instance will be associated with one or more Provenance resource instances, targeting the specific version of the DocumentReference instance. 

The diagram below provides an overview of the required FHIR resources and how they can be interconnected to support a range of document metadata use cases. It shows that there are multiple places in which key event metadata such as event site and event location may be stored, dependent upon the use case. See the dedicated clinical scenario guidance for recommendations on the tailoring of the data model for different circumstances. 

The FHIR data model consists of the following resources: 
* {{pagelink:DataStandardsWales-Device,text:Device}} 
* {{pagelink:DataStandardsWales-DocumentReference,text:DocumentReference}} 
* {{pagelink:DataStandardsWales-Encounter,text:Encounter}} 
* {{pagelink:DataStandardsWales-Location,text:Location}}
* {{pagelink:DataStandardsWales-Organization,text:Organization}}
* {{pagelink:DataStandardsWales-Patient,text:Patient}}
* {{pagelink:DataStandardsWales-Practitioner,text:Practitioner}}
* {{pagelink:DataStandardsWales-PractitionerRole,text:PractitionerRole}}
* {{pagelink:DataStandardsWales-Provenance,text:Provenance}}
* {{pagelink:DataStandardsWales-RelatedPerson,text:RelatedPerson}}
<br />
{{render:Diagrams-Document-metadata-maximal-logical-model}}
<br />

Note that not all of these resource types are explicit in the model above.  Where alternative resource types may fulfil the particular role, the diagram illustrates the one that is preferred or most commonly used. At the current phase the document roles of author, authenticator, committer and senior responsible clinician can all be fulfilled by alternative resource types as specified in the applicable resource profile.  The same resource instance may perform multiple roles in relation to the same document. 

## FHIR Resources
### Device
In the case of autogenerated documents, a Device resource instance may be referenced as the document author. 

### DocumentReference
A DocumentReference resource represents a distinct document and its version history, equivalent to a "supersession set" (see the [Care Document Versions](#care-document-versions) section below). As part of the document metadata, the document reference contains “attachment” details which should include at least the applicable mime-type and a pointer to the URL where the document is stored (or the data binary prior to document storage). Each DocumentReference resource should have a `meta.source` element that identifies the source system using its application identifier (OID). To support seamless searching across new and legacy data in the short to medium term, `meta.tag` instances can be used to store searchable document attributes.

A DocumentReference resource may be related to other distinct DocumentReference resources, for example where one document is an approval slip that “signs” another document.

### Encounter
The documented event may be represented as an Encounter resource instance. In this case applications may access the referenced Encounter to retrieve the event details including document metadata such as event site and event organisation.

### Location
There are two roles that may be fulfilled by a location, as represented by a Location resource instance. The first is the event site, and the second a more specific event location. For example the event location may be a specific ward within a hospital identified as the event site.

### Organization
There are two roles that may be fulfilled by an organisation, as represented by an Organization resource instance. The first is the custodian organisation: the health board responsible for the document, which relates to one of their patients. The second role is as the event organisation i.e. the health board that provided care via the documented event. 

### Patient
Documents will typically have a subject that is a Patient resource instance. The patient may also perform the role of document committer or author. 

### Practitioner
The Practitioner resource carries details of the individual staff member, irrespective of their job role.  A Practitioner resource instance can be involved as author, authenticator, committer or senior responsible clinician. 

### PractitionerRole
Ideally the staff involved with the document as author, authenticator, committer or senior responsible clinician can be referenced via a PractitionerRole resource instance. This facilitates access to richer contextual data than if the Practitioner resource is directly referenced.

### Provenance
The Provenance resource provides an audit trail of when a specific document version was committed and by whom. If patient demographics are also submitted, these are captured in an additional Provenance instance that specifically captures demographics as recorded, to support retrospective analysis. See the dedicated guidance page for clarification of the purpose and use of the Provenance resource:
* {{pagelink:Home/Guidance/Provenance/Index.page.md, text: Provenance Guidance}}

### RelatedPerson
A RelatedPerson resource may be referenced in the role of document committer or author. 

## Supporting Legacy Metadata
Legacy care documents may have associated metadata that are not explicitly covered by the formal content of the DocumentReference or its related resources. In order to avoid data loss on migration, and to support continued acces to the data in the transition phase, these document attributes will be stored as `meta.tag` elements.  Each will have a `.system` value that uniquely identifies the `.display` value within the tag.  For reasons of continuity, the system value will be constructed using the same approach as the SOLR software that continues to contribute to the transition architecture. For example:
- For SetSequenceNumber, `.system` = "seqno"
- For document attribute DocumentSubType, `.system` = "docattr_documentsubtype".

<br />