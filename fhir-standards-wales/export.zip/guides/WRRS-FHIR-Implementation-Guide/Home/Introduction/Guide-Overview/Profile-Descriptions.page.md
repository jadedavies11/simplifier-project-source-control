## {{page-title}}

Profiles listed and referenced within this Implementation guide are inherited from and documented as part of the [Data Standards Wales Implementation Guide](https://simplifier.net/guide/FHIR-Standards-Wales-Implementation-Guide/Home?version=current){target="_blank"}.

For guidance on Profile Descriptions and content please see the [Profile Descriptions](https://simplifier.net/guide/FHIR-Standards-Wales-Implementation-Guide/Home/Introduction/Profile-Descriptions?version=current){target="_blank"} guidance page in the Data Standards Wales Implementation Guide.