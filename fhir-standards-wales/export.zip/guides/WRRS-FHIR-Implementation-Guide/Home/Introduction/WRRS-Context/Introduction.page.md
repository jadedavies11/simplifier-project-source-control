## {{page-title}}
The Welsh Results and Reporting Service (WRRS) was designed to centralise devolved health authority data for the benefit af an All Wales view of patient data. The WRRS, for its initial two years was solely focused on results reporting. All requests are created either on paper or in the health authority itself.
