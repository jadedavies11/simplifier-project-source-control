## {{page-title}}
Pathology is the most prevalent of the results in the WRRS. Pathology covers many departmental areas
- Blood Sciences (BSC)
- Bio-Chemistry (CHM)
- Immunology (IMM)
- Microbiology MIC)
- Histopathology (HIS)
- Haematology
- Screening
- Andrology

Cardiology, Radiology, Genetics, Neurophysiology, Endoscopy, Urology and Respiratory make up the entire departments for results reporting.