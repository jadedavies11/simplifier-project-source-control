<div class="warning"><span class="ImplementWarn"></span></div>

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-UEC-ActivityType, text:DataStandardsWales-UEC-ActivityType}}