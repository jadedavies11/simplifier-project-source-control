<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

{{render:https://fhir.nhs.wales/ValueSet/PASEventType, text:PASEventType}}

PAS Event Type ValueSet is owned and managed by Digital Health and Care Wales WPAS. These are not a data standard and this snapshot is for example use only.