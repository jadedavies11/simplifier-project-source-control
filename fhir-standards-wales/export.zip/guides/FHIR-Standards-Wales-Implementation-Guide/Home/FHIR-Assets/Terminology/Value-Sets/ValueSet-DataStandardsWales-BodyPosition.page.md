<div class="warning"><span class="ImplementWarn"></span></div>

{{render:https://fhir.nhs.wales/ValueSet/DataStandardsWales-BodyPosition, text:DataStandardsWales-DataStandardsWales-BodyPosition}}