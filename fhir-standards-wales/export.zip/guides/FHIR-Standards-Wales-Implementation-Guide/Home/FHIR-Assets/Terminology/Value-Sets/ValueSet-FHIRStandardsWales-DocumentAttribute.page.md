<div class="warning"><span class="ImplementWarn"></span></div>

{{render:https://fhir.nhs.wales/ValueSet/FHIRStandardsWales-DocumentAttribute, text:FHIRStandardsWales-DocumentAttribute}}