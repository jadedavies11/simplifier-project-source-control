<div class="warning"><span class="ImplementWarn"></span></div>

## {{page-title}}

{{render:https://fhir.nhs.wales/ConceptMap/DataStandardsWales-HL7AdministrativeGender-GenderIdentity}}