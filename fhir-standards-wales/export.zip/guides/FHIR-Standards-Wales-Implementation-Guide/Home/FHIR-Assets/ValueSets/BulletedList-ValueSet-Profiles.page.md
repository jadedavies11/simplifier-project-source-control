
The Value Sets created for this Implementation Guide are listed with the Profiles they are assigned to.

<h3>Profiles</h3>

<div style="display:flex; gap:30px; align-items:flex-start;">

  <div style="flex:1;">

<p><b>DataStandardsWales-DocumentReference</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-DocumentCategory}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-DocumentDigitalStatus}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-DocumentType}}</li>
</ul>

<p><b>DataStandardsWales-Encounter-UEC</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-EncounterType}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-UEC-Acuity}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-UEC-ArrivalMode}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-UEC-AttendanceCategory}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-UEC-AttendanceSource}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-UEC-DischargeDestination}}</li>
</ul>

<p><b>DataStandardsWales-Location</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-AliasType}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-LocationForm}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-LocationType}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-LocationTypeCategory}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-LocationTypeExtended}}</li>
</ul>

<p><b>DataStandardsWales-MessageDefinition</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-MessageEvent}}</li>
</ul>

<p><b>DataStandardsWales-MessageHeader</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-MessageEvent}}</li>
</ul>

<p><b>DataStandardsWales-Observation-VitalSigns</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-BodyPosition}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-ObservationVitalSignsType}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting}}</li>
</ul>

<p><b>DataStandardsWales-Observation-VitalSigns-BMI</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-BMI}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting}}</li>
</ul>
</div>

  <div style="flex:1;">

<p><b>DataStandardsWales-Observation-VitalSigns-BodyHeight</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-BodyHeightMeasurements}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting}}</li>
</ul>

<p><b>DataStandardsWales-Observation-VitalSigns-BodyWeight</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-BodyWeightMeasurements}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-RecordingSetting}}</li>
</ul>

<p><b>DataStandardsWales-Organization</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-AliasType}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-OrganizationClassification}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-OrganizationDomain}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-OrganizationSector}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-OrganizationSubclassification}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-OrganizationTypeExtended}}</li>
</ul>

<p><b>DataStandardsWales-Patient</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-GenderIdentity}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-MaritalStatus}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-Occupation}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-Religion}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-Sex}}</li>
    <li>{{pagelink:ValueSet-DataStandardsWales-Title}}</li>
</ul>

<p><b>DataStandardsWales-Provenance</b></p>
<ul>
    <li>{{pagelink:ValueSet-DataStandardsWales-ProvenanceActivity}}</li>
</ul>
</div>

</div>

