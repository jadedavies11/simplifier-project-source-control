## {{page-title}}
An extension to capture Demographics details recorded as at the time of the care record change.

### Purpose
This extends the Provenance resource to capture Demographics details recorded as at the time of the care record change. This will be used to ensure that patient record items are assigned to the correct patient record within the Care Data Repository.

### Context of Use
This extension may be used on the following profile(s):
* Provenance

### Formal Views of Extension Content
<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink tab-active" onclick="openCity(this,'tabsnap')" data-target="tabsnap">
      Snapshot View
    </li>
    <li class="tablink" onclick="openCity(this,'tabeg')" data-target="tabeg">
      Example View
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabsnap" class="tabcontent active">      
      {{tree:https://fhir.nhs.wales/StructureDefinition/Extension-DataStandardsWales-DemographicsAsRecorded, snapshot}}
    </div>
    <div id="tabeg" class="tabcontent">
      <list>
          <li>{{pagelink:Example-DataStandardsWales-Provenance-DemographicsAsRecorded, text:Example Provenance record showing the DemographicsAsRecorded extension}}</li>
      </list>
    </div>
  </div>
</div>