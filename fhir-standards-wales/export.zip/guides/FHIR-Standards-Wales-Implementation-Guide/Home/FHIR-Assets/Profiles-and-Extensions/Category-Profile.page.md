All Profiles in this Implementation Guide grouped by Resource Index category. 

<div style="display:flex; gap:30px; align-items:flex-start;">

  <div style="flex:1;">

<p><b>Allergy:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-AllergyIntolerance}}</li>
    <li>{{pagelink:DataStandardsWales-AllergyList}}</li>
</ul>

<p><b>Data Exchange:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-Composition}}</li>
    <li>{{pagelink:DataStandardsWales-MessageDefinition}}</li>
    <li>{{pagelink:DataStandardsWales-MessageHeader}}</li>
</ul>

<p><b>Diagnostics:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-Condition}}</li>
    <li>{{pagelink:DataStandardsWales-DiagnosticReport}}</li>
    <li>{{pagelink:DataStandardsWales-DiagnosticReport-Lab}}</li>
    <li>{{pagelink:DataStandardsWales-ImagingStudy}}</li>
    <li>{{pagelink:DataStandardsWales-Observation}}</li>
    <li>{{pagelink:DataStandardsWales-Observation-Lab}}</li>
    <li>{{pagelink:DataStandardsWales-Observation-VitalSigns}}</li>
    <li>{{pagelink:DataStandardsWales-Observation-VitalSigns-BMI}}</li>
    <li>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyHeight}}</li>
    <li>{{pagelink:DataStandardsWales-Observation-VitalSigns-BodyWeight}}</li>
    <li>{{pagelink:DataStandardsWales-Specimen}}</li>
</ul>

<p><b>Entities:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-Device}}</li>
    <li>{{pagelink:DataStandardsWales-Endpoint}}</li>
    <li>{{pagelink:DataStandardsWales-HealthcareService}}</li>
    <li>{{pagelink:DataStandardsWales-Location}}</li>
    <li>{{pagelink:DataStandardsWales-Organization}}</li>
    <li>{{pagelink:DataStandardsWales-OrganizationAffiliation}}</li>
    <li>{{pagelink:DataStandardsWales-Questionnaire}}</li>
    <li>{{pagelink:DataStandardsWales-QuestionnaireResponse}}</li>
</ul>
</div>

  <div style="flex:1;">

<p><b>Medication:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-Immunization}}</li>
    <li>{{pagelink:DataStandardsWales-ImmunizationRecommendation}}</li>
    <li>{{pagelink:DataStandardsWales-Medication}}</li>
    <li>{{pagelink:DataStandardsWales-MedicationAdministration}}</li>
    <li>{{pagelink:DataStandardsWales-MedicationDispense}}</li>
    <li>{{pagelink:DataStandardsWales-MedicationList}}</li>
    <li>{{pagelink:DataStandardsWales-MedicationRequest}}</li>
    <li>{{pagelink:DataStandardsWales-MedicationStatement}}</li>
</ul>

<p><b>People:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-Patient}}</li>
    <li>{{pagelink:DataStandardsWales-Practitioner}}</li>
    <li>{{pagelink:DataStandardsWales-PractitionerRole}}</li>
    <li>{{pagelink:DataStandardsWales-RelatedPerson}}</li>
</ul>

<p><b>Security and Privacy:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-AuditEvent}}</li>
    <li>{{pagelink:DataStandardsWales-Consent}}</li>
    <li>{{pagelink:DataStandardsWales-Provenance}}</li>
</ul>

<p><b>Workflow:</b></p>
<ul>
    <li>{{pagelink:DataStandardsWales-Appointment}}</li>
    <li>{{pagelink:DataStandardsWales-DocumentReference}}</li>
    <li>{{pagelink:DataStandardsWales-Encounter}}</li>
    <li>{{pagelink:DataStandardsWales-Encounter-UEC}}</li>
    <li>{{pagelink:DataStandardsWales-ServiceRequest}}</li>
    <li>{{pagelink:DataStandardsWales-Task}}</li>
</ul>
</div>

</div>