## Example Appointment - General Surgery

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:Appointment/Example-DataStandardsWales-Appointment-GenSurgery}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:Appointment/Example-DataStandardsWales-Appointment-GenSurgery}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:Appointment/Example-DataStandardsWales-Appointment-GenSurgery}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:Appointment/Example-DataStandardsWales-Appointment-GenSurgery}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:Appointment/Example-DataStandardsWales-Appointment-GenSurgery}}
    </div>  
  </div>
</div>