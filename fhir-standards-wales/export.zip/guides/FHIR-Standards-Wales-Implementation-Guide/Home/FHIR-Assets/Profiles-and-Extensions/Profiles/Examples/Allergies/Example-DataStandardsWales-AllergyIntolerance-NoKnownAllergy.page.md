## Example AllergyIntolerance - No known allergies
This shows an example recording a patient that is known to have no allergies.

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:List/Example-DataStandardsWales-List-Allergies-NoKnownAllergy}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:List/Example-DataStandardsWales-List-Allergies-NoKnownAllergy}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:List/Example-DataStandardsWales-List-Allergies-NoKnownAllergy}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:List/Example-DataStandardsWales-List-Allergies-NoKnownAllergy}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:List/Example-DataStandardsWales-List-Allergies-NoKnownAllergy}}
    </div>  
  </div>
</div>