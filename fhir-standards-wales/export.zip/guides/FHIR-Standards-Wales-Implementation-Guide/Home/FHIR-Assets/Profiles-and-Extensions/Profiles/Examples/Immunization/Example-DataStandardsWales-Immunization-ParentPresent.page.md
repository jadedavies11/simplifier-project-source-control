### Example Immunization - Parent Present

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>   
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtable" class="tabcontent">
      {{table:example-datastandardswales-immunization-ParentPresent}}
    </div>       
    <div id="tabjson" class="tabcontent">
      {{json:example-datastandardswales-immunization-ParentPresent}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:example-datastandardswales-immunization-ParentPresent}}
    </div>  
  </div>
</div>