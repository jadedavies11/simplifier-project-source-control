### {{page-title}}

The following Profiles have been defined for this implementation guide.
* {{pagelink:DataStandardsWales-AllergyIntolerance}}
* {{pagelink:DataStandardsWales-AllergyList}}
* {{pagelink:DataStandardsWales-DiagnosticReport}}
* {{pagelink:DataStandardsWales-DiagnosticReport-Lab}}
* {{pagelink:DataStandardsWales-Dosage}}
* {{pagelink:DataStandardsWales-Encounter}}
* {{pagelink:DataStandardsWales-Endpoint}}
* {{pagelink:DataStandardsWales-ImagingStudy}}
* {{pagelink:DataStandardsWales-Immunization}}
* {{pagelink:DataStandardsWales-Location}}
* {{pagelink:DataStandardsWales-Medication}}
* {{pagelink:DataStandardsWales-MedicationAdministration}}
* {{pagelink:DataStandardsWales-MedicationDispense}}
* {{pagelink:DataStandardsWales-MedicationList}}
* {{pagelink:DataStandardsWales-MedicationRequest}}
* {{pagelink:DataStandardsWales-MedicationStatement}}
* {{pagelink:DataStandardsWales-Observation}}
* {{pagelink:DataStandardsWales-Observation-Lab}}
* {{pagelink:DataStandardsWales-Organization}}
* {{pagelink:DataStandardsWales-Patient}}
* {{pagelink:DataStandardsWales-Practitioner}}
* {{pagelink:DataStandardsWales-PractitionerRole}}
* {{pagelink:DataStandardsWales-ServiceRequest}}
* {{pagelink:DataStandardsWales-Specimen}}