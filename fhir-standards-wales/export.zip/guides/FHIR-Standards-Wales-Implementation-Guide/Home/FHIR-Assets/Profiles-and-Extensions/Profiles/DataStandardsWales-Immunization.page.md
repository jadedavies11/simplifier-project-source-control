---
name: DataStandardsWalesImmunization
---

## {{page-title}}

The [Immunization](https://www.hl7.org/fhir/r4/immunization.html) resource is a record of the immunization received by a patient, often in the form of a vaccine.

The {{page-title}} profile is derived from the [UK Core Immunization Profile](https://simplifier.net/guide/UK-Core-Implementation-Guide-STU2/Home/ProfilesandExtensions/Profile-UKCore-Immunization?version=2.0.1). It defines additional rules for use within health and care organisations in Wales.

A direct link to the Data Standards Wales asset can be accessed here - {{link:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Immunization}}

### Formal Views of Profile Content
<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink tab-active" onclick="openCity(this,'tabsnap')" data-target="tabsnap">
      Snapshot View
    </li>
    <li class="tablink" onclick="openCity(this,'tabdiff')" data-target="tabdiff">
      Differential View
    </li>
    <li class="tablink" onclick="openCity(this,'tabhybrid')" data-target="tabhybrid">
      Hybrid View
    </li>
    <li class="tablink" onclick="openCity(this,'tabeg')" data-target="tabeg">
      Examples
    </li>    
  </ul>
  <div class="tab-main">
    <div id="tabsnap" class="tabcontent active">      
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Immunization, snapshot}}
    </div>
    <div id="tabdiff" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Immunization, diff}}
  </div>
    <div id="tabhybrid" class="tabcontent">
      {{tree:https://fhir.nhs.wales/StructureDefinition/DataStandardsWales-Immunization, hybrid}}
  </div>
  <div id="tabeg" class="tabcontent">

- {{pagelink:ImmunizationFluVaccine, text: Example Immunization - Flu Vaccine}} 
- {{pagelink:ImmunizationNotGiven, text: Example Immunization - Not Given}} 
- {{pagelink:ImmunizationParentPresent, text: Example Immunization - Parent Present}} 

_*Examples provided have been clinically assured on the 07-Aug-2024_
  </div>    
</div>

---

## Profile Specific Implementation Guidance: ##

### Mandatory and Must Support Data Elements
Refer to the {{pagelink:Mandatory-and-Must-Support-Data-Elements,text: Mandatory and Must Support}} page for guidance on how these elements should be interpreted.

Each Immunization **must have**:

|Element|Reason|
|-|-|
|`Immunization.status`|Will generally be set to show that the immunisation has been completed or not done.|
|`Immunization.vaccineCode`|Vaccine product administered.|
|`Immunization.patient`|The patient who either received or did not receive the immunisation.|
|`Immunization.occurrence[x]`|Date vaccine administered or was to be administered.|


Each Immunization **must support**:

|Element|Reason|
|-|-|
|`Immunization.identifier`|A unique identifier assigned to this immunisation record.|
|`Immunization.statusReason`|Indicates the reason the immunization event was not performed.|
|`Immunization.recorded`|When the immunisation was first captured in the subject's record.|
|`Immunization.reportOrigin`|Indicates the source of a secondarily reported record.|
|`Immunization.location`|The service delivery location where the immunisation administration occurred.|
|`Immunization.manufacturer`|Name of vaccine manufacturer.|
|`Immunization.lotNumber`|Lot number of the vaccine product.|
|`Immunization.expirationDate`|Date vaccine batch expires.|
|`Immunization.site`|Body site where vaccine was administered.|
|`Immunization.route`|The path by which the vaccine product is taken into the body.|
|`Immunization.doseQuantity`|The quantity of vaccine product that was administered.|
|`Immunization.performer`|Indicates who performed the immunization event.|
|`Immunization.reasonCode`|Reasons why the vaccine was administered.|
|`Immunization.protocolApplied`|The protocol being followed by the provider who administered the dose.|

### Extensions

The extensions listed below allow a number of the data elements listed above to be supported where not currently supported by the FHIR standard:
  * Data Standards Wales extensions
    * {{pagelink:Extension-DataStandardsWales-AdministeredProduct,text:DataStandardsWales-AdministeredProduct}}
    * {{pagelink:Extension-DataStandardsWales-DateProcedureLastUpdated,text:DataStandardsWales-DateProcedureLastUpdated}}
    * {{pagelink:Extension-DataStandardsWales-ForecastCreationSource,text:DataStandardsWales-ForecastCreationSource}}

  * Backport extensions
    * The following extension is based on elements in the [HL7 R5 Immunization](https://www.hl7.org/fhir/r5/immunization.html) resource definition. See {{pagelink:Home/Help-and-Support/Deployment.page.md}} for more information on dependencies.
      * **ExtensionImmunization_basedOn** supports the identification of the request or recommendation fulfilled by the immunization event. It is based on `Immunization.basedOn` in R5.