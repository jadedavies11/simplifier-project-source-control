<div class="warning"><span class="ClinicalWarn"></span></div>

### Example Questionnaire Response - Growth Chart Condition

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink" onclick="openCity(this,'tabtable')" data-target="tabtable">
      Table
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>    
    <li class="tablink" onclick="openCity(this,'tabjson')" data-target="tabjson">
      JSON
    </li>    
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:QuestionnaireResponse/Example-DataStandardsWales-QuestionnaireResponse-GrowthChartCondition}}
    </div>
    <div id="tabtable" class="tabcontent">
      {{table:QuestionnaireResponse/Example-DataStandardsWales-QuestionnaireResponse-GrowthChartCondition}}
    </div>       
    <div id="tabxml" class="tabcontent active">      
      {{xml:QuestionnaireResponse/Example-DataStandardsWales-QuestionnaireResponse-GrowthChartCondition}}
    </div>
    <div id="tabjson" class="tabcontent">
      {{json:QuestionnaireResponse/Example-DataStandardsWales-QuestionnaireResponse-GrowthChartCondition}}
    </div>       
    <div id="tabnarrative" class="tabcontent">
      {{narrative:QuestionnaireResponse/Example-DataStandardsWales-QuestionnaireResponse-GrowthChartCondition}}
    </div>  
  </div>
</div>