---
topic: DosageDrops
---


### Example Dosage - Drops

<div class="tab-wrap">
  <ul class="tab-head">
    <li class="tablink" onclick="openCity(this,'tabtree')" data-target="tabtree">
      Overview
    </li>
    <li class="tablink tab-active" onclick="openCity(this,'tabxml')" data-target="tabxml">
      XML
    </li>       
    <li class="tablink" onclick="openCity(this,'tabnarrative')" data-target="tabnarrative">
      Narrative
    </li>
  </ul>
  <div class="tab-main">
    <div id="tabtree" class="tabcontent">
      {{tree:examples-dosage-example-datastandardswales-dosage-drops}}
    </div>
    <div id="tabxml" class="tabcontent active">      
      {{xml:examples-dosage-example-datastandardswales-dosage-drops}}
    </div>  
    <div id="tabnarrative" class="tabcontent">
      {{narrative:examples-dosage-example-datastandardswales-dosage-drops}}
    </div>  
  </div>
</div>