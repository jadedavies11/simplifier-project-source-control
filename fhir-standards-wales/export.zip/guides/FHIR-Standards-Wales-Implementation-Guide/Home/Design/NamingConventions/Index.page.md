## {{page-title}}

These naming conventions are applicatble to FHIR confomance (i.e. StructureDefinition, CodeSystem, ConceptMap, ValueSet, etc.) resources published within Wales Data Standards Wales FHIR profiles and as part of this implementation guide.