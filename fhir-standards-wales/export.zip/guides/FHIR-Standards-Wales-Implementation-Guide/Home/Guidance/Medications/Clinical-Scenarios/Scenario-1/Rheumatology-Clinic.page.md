### 2) Rheumatology Clinic

{{pagelink:Example-DataStandardsWales-List-Medications-Outpatient, text: Example list of medications for the patient as recorded at an outpatient clinic}}.
* Enbrel (Etanercept) 50mg/1ml solution for injection pre-filled syringes, Inject 50mg subcutaneously once a week _(Note: prescribed by brand (AMP level) as it’s a biologic)_