### {{page-title}}
This section lists FHIR [extensions](https://hl7.org/fhir/R4/extensibility.html) that have been defined to support Welsh-specific data standards or use-cases.

These extensions can be used in addition to those defined within UK Core. Please refer to the [extensions](https://simplifier.net/guide/UK-Core-Implementation-Guide/Home/ProfilesandExtensions?version=current) section within the UK Core Implementation Guide for further information.