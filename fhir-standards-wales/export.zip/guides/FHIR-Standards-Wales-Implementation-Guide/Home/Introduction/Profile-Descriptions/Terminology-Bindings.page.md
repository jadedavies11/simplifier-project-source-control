### {{page-title}}
This section shows any terminology bindings defined for use within the Data Standards Wales profile.

Note that this section does not repeat information on bindings defined for use within the FHIR R4 or UK Core implementation guides.