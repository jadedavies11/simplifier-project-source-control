### {{page-title}}
This guide contains the following:

* Contents: To which a set of logical statements that implementations must confirm. These are almost always [conformance resources](https://www.hl7.org/fhir/conformance-module.html). These are published in the FHIR Assets section.
* Examples: Examples that illustrate the intent of the profiles defined in this guide. 