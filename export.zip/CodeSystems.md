## CodeSystems

- {{pagelink:CodeSystemCPIS-ObservationType}}