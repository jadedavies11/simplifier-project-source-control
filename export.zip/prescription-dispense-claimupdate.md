#### prescription-dispense-claim update

An updated claim replacing {{pagelink:prescription-dispense-claim}}

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:Bundle-8fbee4e0-35ca-41ef-935e-b21f02ed0ea2}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:Bundle-8fbee4e0-35ca-41ef-935e-b21f02ed0ea2}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:Bundle-8fbee4e0-35ca-41ef-935e-b21f02ed0ea2}}
    </div>
  </div>
</div>
