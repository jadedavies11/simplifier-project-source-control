## Integration with SPINE

Further information about [how to integrate with NHS SPINE](https://digital.nhs.uk/developer/guides-and-documentation/security-and-authorisation) is available.

