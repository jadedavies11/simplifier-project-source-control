## Profiles

The page lists the profiles used by Child Protection Information Sharing:-

- {{pagelink:AuditEvent}}
- {{pagelink:Bundle}}
- {{pagelink:CarePlan}}
- {{pagelink:Device}}
- {{pagelink:List}}
- {{pagelink:Organization}}
- {{pagelink:Patient}}
- {{pagelink:Practitioner}}
- {{pagelink:PractitionerRole}}


