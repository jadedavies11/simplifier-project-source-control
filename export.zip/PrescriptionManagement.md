## {{page-title}}

EPS is an implementation of [FHIR Workflow Management](https://www.hl7.org/fhir/workflow-management.html) and implements those patterns. These are focused on the FHIR Task resource which is used to represent the 'prescription' within EPS. 