## CodeSystem CPIS-ObservationType

{{render:https://fhir.nhs.uk/R4/CodeSystem/CPIS-ObservationType}}