### 2nd dispense event - partial

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:Bundle-a7849e19-6f4a-4336-a4ef-8962e2f7e684}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:Bundle-a7849e19-6f4a-4336-a4ef-8962e2f7e684}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:Bundle-a7849e19-6f4a-4336-a4ef-8962e2f7e684}}
    </div>
  </div>
</div>
