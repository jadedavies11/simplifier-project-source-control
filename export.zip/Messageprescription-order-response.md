### Message prescription-order-response

- {{pagelink:PrescriptionOrderHomecareResponse.md}} homecare order cancellation response example.
- {{pagelink:PrescriptionOrderHomecaseSubsequentResponse.md}} Subsequent message received after the prescription was returned unissued by pharmacist.