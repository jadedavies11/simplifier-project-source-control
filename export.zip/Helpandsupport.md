## Help and support

<!-- Do not remove this default text below -->

<!-- {{render:nhs-digital-logo}} -->

If you have any questions, need further information, or wish to provide feedback on this implementation guide, please e-mail: <a href="mailto:interoperabilityteam@nhs.net?subject=Child%20Protection%20Specification">Interoperability Team</a>.

