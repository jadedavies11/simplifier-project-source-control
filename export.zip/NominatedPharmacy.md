## {{page-title}}

For nominated or one off prescriptions EPS will assign the Task based on

- one-off nomination in the {{pagelink:prescriptionorder}}
- patients nomination recorded in PDS (the patient can change this via NHSApp)

{{render:release-nominated}}

1. The {{pagelink:PrescriptionRelease}} operation is used to retrieve the prescriptions using the pharmacies ODS code as a parameter.