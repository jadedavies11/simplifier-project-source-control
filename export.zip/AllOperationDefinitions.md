#### All OperationDefinitions

  - {{pagelink:OperationDefinitionCPIS-GetBundle}}