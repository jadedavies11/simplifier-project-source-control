## {{page-title}}

| FHIR Exchange | API | FHIR Resource |
|--
| FHIR RESTful | <a href="https://digital.nhs.uk/developer/api-catalogue/electronic-prescription-service-fhir#api-Dispensing-send-dispense-claim-message">POST /Claim</a> | {{pagelink:NHSDigital-Claim.md }} |


<br>

This interaction is used to submit a prescription claim to NHS BSA.