## Extensions

This page lists the extensions used by Child Protection Information Sharing:-

- {{pagelink:ExtensionCPIS-AssignedEntity}}
- {{pagelink:ExtensionCPIS-TotalCarePlans}}
- {{pagelink:ExtensionCPIS-TotalRecords}}