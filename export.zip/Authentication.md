## Authentication

- [Integration with SPINE](https://simplifier.net/guide/ChildProtection/IntegrationwithSPINE)


