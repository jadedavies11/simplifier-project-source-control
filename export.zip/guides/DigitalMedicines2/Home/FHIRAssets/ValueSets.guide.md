## ValueSets

The following ValueSets are defined in this implementation Guide.


|ValueSet|Description|
|--
|{{pagelink:DM-Medicationrequest-Code-duplicate-2}} ||
|{{pagelink:DM-Medicationdispense-Code-duplicate-2}} ||
|{{pagelink:DM-Medicationdispense-type-duplicate-2}} ||
|{{pagelink:DM-Medicationdispense-status-reason-duplicate-2}} ||
|{{pagelink:DM-medicationrequest-category-duplicate-2}}||
|{{pagelink:DM-medicationrequest-controlled-drug-duplicate-2}}||
|{{pagelink:DM-MedicationRequest-Status-Reason-duplicate-2}}||
|{{pagelink:DM-Performer-Site-Type-duplicate-2}} || 
|{{pagelink:DM-prescription-endorsement-duplicate-2}} || 
|{{pagelink:DM-prescription-therapy-type-duplicate-2}}| See {{pagelink:DM-medicationrequest-course-of-therapy-duplicate-2}} for replacement |
|{{pagelink:DM-prescription-type-duplicate-2}}||
|{{pagelink:DM-medicationrequest-course-of-therapy-duplicate-2}}| Replacement for {{pagelink:DM-prescription-therapy-type-duplicate-2}} |
| {{pagelink:DM-Task-Reason-Code-duplicate-2}} |
| {{pagelink:DM-Task-Status-Reason-duplicate-2}} ||
| {{pagelink:DM-Prescription-Task-status-reason2}} ||
| {{pagelink:DM-prescription-release-rejection-reason-duplicate-2}} ||

