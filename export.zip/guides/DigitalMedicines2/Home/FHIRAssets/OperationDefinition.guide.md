## OperationDefinition

|OperationDefinition|Description|
|--
|{{pagelink:prepare-duplicate-2}} ||
| [process-message](https://simplifier.net/guide/nhsdigital/Home/FHIRAssets/AllAssets/OperationDefinition/process-message) ||
|{{pagelink:release2}} | Release a prescription (Task)| 
| {{pagelink:Home/FHIRAssets/AllAssets/OperationDefinition-duplicate-2/verify-signature.page.md}} | |