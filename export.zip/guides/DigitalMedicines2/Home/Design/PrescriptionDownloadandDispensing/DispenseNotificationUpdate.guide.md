## {{page-title}}

| FHIR Exchange | API | Event Type | FHIR (Bundle) Message Definition |
|--
|FHIR Messaging | [POST /$process-message](https://digital.nhs.uk/developer/api-catalogue/electronic-prescription-service-fhir#api-Dispensing-send-dispense-notification-message) |  `dispense-notification-update` | {{pagelink:dispense-notification-update-duplicate-2}} |

<br>

This interaction is used to amend a previously sent `dispense-notification`