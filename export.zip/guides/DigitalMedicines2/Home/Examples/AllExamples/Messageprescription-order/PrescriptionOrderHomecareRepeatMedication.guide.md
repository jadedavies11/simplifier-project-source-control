### Prescription Order Homecare Repeat Medication

Outpatient repeat disensing single item prescription for 4 x weekly issues. This is very similar to the {{pagelink:prescriptionorderhomecareprepare}} message with the addition of the a digital signature in the Provenence resource.


<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:Bundle-DC2C66-A1B2C3-23407B-duplicate-2}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:Bundle-DC2C66-A1B2C3-23407B-duplicate-2}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:Bundle-DC2C66-A1B2C3-23407B-duplicate-2}}
    </div>
  </div>
</div>
