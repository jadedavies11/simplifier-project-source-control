### Message dispense-notification

- {{pagelink:prescription-dispense-notification-duplicate-2}} Partial dispensed prescription
- {{pagelink:stdispenseevent-partial}}
- {{pagelink:nddispenseevent-partial}}
- {{pagelink:rddispenseevent-completed}}
- {{pagelink:stdispenseevent-partialwithPatientResource}}

<br />
