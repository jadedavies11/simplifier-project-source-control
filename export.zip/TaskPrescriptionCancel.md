### {{page-title}}

A cancel prescription order, cancels the prescription fulfilment request.

<div class="nhsd-!t-margin-bottom-6">
  <ul class="nav nav-tabs" role="tablist">
        <li role="presentation" class="active">
            <a href="#JSON" role="tab" data-toggle="tab">JSON</a>
        </li>
         <li role="presentation">
            <a href="#XML" role="tab" data-toggle="tab">XML</a>
        </li>
        <li role="presentation">
            <a href="#Tree" role="tab" data-toggle="tab">Tree</a>
        </li>
  </ul>
    
  <div class="tab-content snippet">
    <div id="JSON" role="tabpanel" class="tab-pane active">
{{json:Task-1291fcca-902b-48f3-9d07-1be9ea30d7a0}}
    </div>
    <div id="XML" role="tabpanel" class="tab-pane">
{{xml:Task-1291fcca-902b-48f3-9d07-1be9ea30d7a0}}
    </div>
    <div id="Tree" role="tabpanel" class="tab-pane">
{{tree:Task-1291fcca-902b-48f3-9d07-1be9ea30d7a0}}
    </div>
  </div>
</div>