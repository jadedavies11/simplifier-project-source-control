## CPIS Bundle example

<div class="tab">
  <button class="tablinks active" onclick="openTab(event, 'JSON')">JSON</button>
  <button class="tablinks" onclick="openTab(event, 'XML')">XML</button>
</div>
<div id="XML" class="tabcontent">
{{xml:CPIS-NHSQueryResponse-Example}}
</div>
<div id="JSON" class="tabcontent" style="display:block">
{{json:CPIS-NHSQueryResponse-Example}}
</div>